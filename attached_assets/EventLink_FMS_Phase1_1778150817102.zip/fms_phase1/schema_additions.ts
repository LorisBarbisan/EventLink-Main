// ============================================================
// FMS Phase 1 — Schema additions
// Add these exports to: shared/schema.ts
// ============================================================
//
// INSTRUCTIONS:
// 1. Open shared/schema.ts
// 2. Add the imports below to the existing import block at the top
// 3. Paste the table definitions and type exports anywhere after
//    the existing table definitions (e.g. after the "ratings" table)
//
// ============================================================

// --- Add to existing imports at the top of schema.ts ---
// (pgTable, text, integer, boolean, timestamp, serial should already be imported)
// Just make sure these are present in your existing drizzle-orm/pg-core import:
//   serial, text, integer, timestamp, uniqueIndex, index

// ============================================================
// PASTE THIS BLOCK into shared/schema.ts
// ============================================================

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id")
    .notNull()
    .references(() => jobs.id, { onDelete: "cascade" }),
  employerId: integer("employer_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  freelancerId: integer("freelancer_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  // Status workflow: enquired → confirmed → briefed → completed
  // Can be cancelled from any status
  status: text("status").notNull().default("enquired"),
  agreedRate: text("agreed_rate"),
  callTime: text("call_time"),
  venueAddress: text("venue_address"),
  employerNotes: text("employer_notes"),
  cancellationReason: text("cancellation_reason"),
  cancelledBy: text("cancelled_by"), // 'employer' | 'freelancer'
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const bookingStatusHistory = pgTable("booking_status_history", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id")
    .notNull()
    .references(() => bookings.id, { onDelete: "cascade" }),
  fromStatus: text("from_status"),
  toStatus: text("to_status").notNull(),
  changedById: integer("changed_by_id")
    .notNull()
    .references(() => users.id),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ============================================================
// Zod validation schemas — add these too
// ============================================================

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateBookingSchema = createInsertSchema(bookings)
  .omit({ id: true, jobId: true, employerId: true, freelancerId: true, createdAt: true })
  .partial();

export const bookingStatusValues = [
  "enquired",
  "confirmed",
  "briefed",
  "completed",
  "cancelled",
] as const;

export type BookingStatus = (typeof bookingStatusValues)[number];

// ============================================================
// Type exports
// ============================================================
export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = typeof bookings.$inferInsert;
export type BookingStatusHistory = typeof bookingStatusHistory.$inferSelect;
