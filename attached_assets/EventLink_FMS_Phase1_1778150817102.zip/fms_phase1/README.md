# FMS Phase 1 — Drop-in Instructions for Replit

## What this implements

Booking confirmation workflow for the EventLink Freelance Management System.
When an employer contacts a freelancer about a job, a booking record is created
and tracked through: enquired → confirmed → briefed → completed (or cancelled).

---

## Step 1 — Run the migration

Copy `0006_fms_phase1_bookings.sql` into the `migrations/` folder.

Then run it against the database. In Replit terminal:

```bash
npx drizzle-kit push
```

Or if you run migrations manually:
```bash
psql $DATABASE_URL -f migrations/0006_fms_phase1_bookings.sql
```

---

## Step 2 — Add schema types

Open `shared/schema.ts`.

Paste the entire contents of `schema_additions.ts` at the bottom of the file,
before the final closing brace/export.

The only thing to check: make sure `pgTable`, `serial`, `text`, `integer`,
`timestamp`, `boolean` are already in your drizzle-orm imports at the top.
They almost certainly are. The new tables reference `jobs` and `users` which
already exist in schema.ts.

---

## Step 3 — Add the controller

Copy `booking.controller.ts` into:
```
server/api/controllers/booking.controller.ts
```

---

## Step 4 — Add the routes

Copy `booking.route.ts` into:
```
server/api/routes/booking.route.ts
```

---

## Step 5 — Register the routes

Open `server/api/routes/index.ts` (or wherever routes are registered —
look for the file that imports all the route files).

Add these two lines:

```typescript
import bookingRouter from "./booking.route";

// Add alongside the other router.use() calls:
router.use("/bookings", bookingRouter);
```

---

## Step 6 — Add frontend pages

Copy `MyBookings.tsx` into:
```
client/src/pages/employer/MyBookings.tsx
```

Copy `MyJobs.tsx` into:
```
client/src/pages/freelancer/MyJobs.tsx
```

---

## Step 7 — Register frontend routes

Open your router file (likely `client/src/App.tsx` or `client/src/router.tsx`).

Add the imports and routes:

```tsx
import MyBookings from "./pages/employer/MyBookings";
import MyJobs from "./pages/freelancer/MyJobs";

// Inside your Routes/Switch:
<Route path="/employer/bookings" element={<MyBookings />} />
<Route path="/freelancer/bookings" element={<MyJobs />} />
```

---

## Step 8 — Add nav links

In the employer dashboard nav, add a link to `/employer/bookings`.
In the freelancer dashboard nav, add a link to `/freelancer/bookings`.

---

## Step 9 — Auto-create bookings when employer contacts a freelancer

This is the key integration. Find wherever an employer sends the first
message to a freelancer about a job (in `message.controller.ts` or
`message.route.ts`).

After the message is sent, add this call:

```typescript
import { db } from "../../storage";
import { bookings } from "../../../shared/schema";

// After sending message — create a booking record if one doesn't exist
const existingBooking = await db
  .select()
  .from(bookings)
  .where(
    and(
      eq(bookings.jobId, jobId),
      eq(bookings.freelancerId, recipientId)
    )
  );

if (existingBooking.length === 0 && jobId) {
  await db.insert(bookings).values({
    jobId,
    employerId: senderId,
    freelancerId: recipientId,
    status: "enquired",
  });
}
```

If you are not sure where to add this, ask Replit Agent to:
"When an employer sends the first message to a freelancer about a specific job,
automatically create a booking record in the bookings table with status 'enquired'.
Use the job_id from the message context. Only create one booking per job+freelancer
pair — check for duplicates first."

---

## API endpoints created

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/bookings | employer | Create a booking |
| GET | /api/bookings/employer | employer | Get all employer bookings |
| GET | /api/bookings/employer/summary | employer | Dashboard counts |
| GET | /api/bookings/job/:jobId | employer | Bookings for a specific job |
| PATCH | /api/bookings/:id/details | employer | Update rate, notes, call time |
| GET | /api/bookings/freelancer | freelancer | Get all freelancer bookings |
| GET | /api/bookings/:id | either | Single booking with history |
| PATCH | /api/bookings/:id/status | either | Update booking status |

---

## Middleware note

The routes use `requireAuth` and `requireRole`. Check that these middleware
functions exist in your project at:
- `server/api/middleware/auth.middleware.ts` (exports `requireAuth`)
- `server/api/middleware/role.middleware.ts` (exports `requireRole`)

If your project uses different middleware names, update the imports in
`booking.route.ts` to match.

---

## That is everything. No other files need to change.
