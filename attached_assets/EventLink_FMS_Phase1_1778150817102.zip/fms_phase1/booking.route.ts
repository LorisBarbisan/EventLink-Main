// ============================================================
// FMS Phase 1 — Booking Routes
// File: server/api/routes/booking.route.ts
// ============================================================

import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import { requireRole } from "../middleware/role.middleware";
import {
  createBooking,
  getEmployerBookings,
  getFreelancerBookings,
  getBookingById,
  updateBookingStatus,
  updateBookingDetails,
  getBookingsByJob,
  getBookingsSummary,
} from "../controllers/booking.controller";

const router = Router();

// ── All booking routes require authentication ─────────────
router.use(requireAuth);

// ── Employer routes ───────────────────────────────────────
// Get all bookings for the employer dashboard
router.get(
  "/employer",
  requireRole("employer"),
  getEmployerBookings
);

// Get summary counts for the employer dashboard widget
router.get(
  "/employer/summary",
  requireRole("employer"),
  getBookingsSummary
);

// Get all bookings for a specific job
router.get(
  "/job/:jobId",
  requireRole("employer"),
  getBookingsByJob
);

// Create a new booking (employer initiates when contacting a freelancer)
router.post(
  "/",
  requireRole("employer"),
  createBooking
);

// Update booking details (notes, rate, call time, venue)
router.patch(
  "/:id/details",
  requireRole("employer"),
  updateBookingDetails
);

// ── Freelancer routes ─────────────────────────────────────
// Get all bookings where this freelancer is booked
router.get(
  "/freelancer",
  requireRole("freelancer"),
  getFreelancerBookings
);

// ── Shared routes (both employer and freelancer) ──────────
// Get a single booking with full history
// (access control is inside the controller)
router.get("/:id", getBookingById);

// Update booking status (workflow transitions)
// Both employer and freelancer can cancel; only employer can progress
router.patch("/:id/status", updateBookingStatus);

export default router;
